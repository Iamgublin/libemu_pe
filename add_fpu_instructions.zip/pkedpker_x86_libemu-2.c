#ifndef HAVE_EMU_FPU_INSTRUCTION_H
#define HAVE_EMU_FPU_INSTRUCTION_H

#define FPU_MOD(fpu_modrm) (fpu_modrm >> 6)
#define FPU_RM(fpu_modrm) (fpu_modrm & 7)

#define FPU_MF(fpu_opcode) ((fpu_opcode >> 1) & 3)

struct emu_fpu_instruction
{
	uint16_t prefixes;
	
	uint8_t fpu_opcode;
	uint8_t fpu_modrm;
	
	uint32_t ea;
	
	/* custom added */
	//FpuMmxRegister r[8];
	uint16_t control;
	uint16_t status;
	uint16_t tag;
	uint32_t lastIP;
	uint32_t lastIPseg;
	uint32_t lastDataPointer;
	uint32_t lastDataSeg;
	uint16_t opcode;
	/* custom added */
	
	uint32_t last_instr;

};

#endif