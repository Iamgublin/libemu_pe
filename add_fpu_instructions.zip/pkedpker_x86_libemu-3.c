			else /* fpu */
			{
				/* this is a minimal parser without exact decomposition
				 * into all fields. instead it determines the length of
				 * the instruction and ignores pretty much everything else
				 * except for a few explicitly implemented instructions. */
				c->instr.is_fpu = 1;
				c->instr.fpu.prefixes = c->instr.prefixes;

				c->instr.fpu.fpu_opcode = c->instr.opc;

				ret = emu_memory_read_byte(c->mem, c->eip++, &c->instr.fpu.fpu_modrm);
				if( ret != 0 )
					return ret;
				
				if( FPU_MOD(c->instr.fpu.fpu_modrm) != 3 ) /* intel pdf page 36 */
				{
					/* trivial case, one register is ea */
		   			if( FPU_RM(c->instr.fpu.fpu_modrm) != 4 && !(FPU_MOD(c->instr.fpu.fpu_modrm) == 0 && FPU_RM(c->instr.fpu.fpu_modrm) == 5) )
						c->instr.fpu.ea = c->reg[FPU_RM(c->instr.fpu.fpu_modrm)];
					else
						c->instr.fpu.ea = 0;
					
					/* sib byte */
					if( FPU_RM(c->instr.fpu.fpu_modrm) == 4 )
					{
						ret = emu_memory_read_byte(c->mem, c->eip++, &byte);
			
						if( ret != 0 )
							return ret;
						
						if( SIB_BASE(byte) != 5 )
						{
							c->instr.fpu.ea += c->reg[SIB_BASE(byte)];
						}
						else if( FPU_MOD(c->instr.fpu.fpu_modrm) != 0 )
						{
							c->instr.fpu.ea += c->reg[ebp];
						}

						if( SIB_INDEX(byte) != 4 )
						{
							c->instr.fpu.ea += c->reg[SIB_INDEX(byte)] * scalem[SIB_SCALE(byte)];
						}
					}
					
					/* modrm */
					if( FPU_MOD(c->instr.fpu.fpu_modrm) == 1 )
					{
						ret = emu_memory_read_byte(c->mem, c->eip++, &byte);

						if( ret != 0 )
							return ret;
						
						c->instr.fpu.ea += (int8_t)byte;
					}
					else if( FPU_MOD(c->instr.fpu.fpu_modrm) == 2 || (FPU_MOD(c->instr.fpu.fpu_modrm) == 0 && FPU_RM(c->instr.fpu.fpu_modrm) == 5) ) 
					{
						uint32_t dword;
						ret = emu_memory_read_dword(c->mem, c->eip, &dword);
						c->eip += 4;

						if( ret != 0 )
							return ret;

						c->instr.fpu.ea += dword;
					}
				}