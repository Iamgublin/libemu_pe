int32_t emu_cpu_step(struct emu_cpu *c, bool print_instruction)
{
	int32_t ret = 0;

	/* call the function */
	if( c->instr.is_fpu == 0 )
	{
		if( c->instr.cpu.prefixes & PREFIX_FS_OVR )
		{
			emu_memory_segment_select(c->mem, s_fs);
		}

		if( c->instr.cpu.prefixes & PREFIX_ES_OVR ) // <-- that was no fun to find! dzzie 4.10.13 
		{
			emu_memory_segment_select(c->mem, s_es);
		}
		
		ret = c->cpu_instr_info->function(c, &c->instr.cpu);

		if( c->instr.cpu.prefixes & PREFIX_FS_OVR )
		{
			emu_memory_segment_select(c->mem, s_cs);
		}

		if( c->instr.cpu.prefixes & PREFIX_ES_OVR ) //dzzie 4.10.13 
		{
			emu_memory_segment_select(c->mem, s_cs);
		}
		
	}
	else
	{
		printf("FPU OPCODE: %x %x\n", c->instr.fpu.fpu_opcode, c->instr.fpu.fpu_modrm);
		/* for now we only support three critical instructions. */
		
		/* FPU opcodes = 0xd8, 0xd9, 0xda, 0xdb, 0xdc, 0xdd, 0xde, 0xdf */
		
		switch(c->instr.fpu.fpu_opcode) {
			case 0xd8: /* FPU Group #1 */
				switch(c->instr.fpu.fpu_modrm) {
					case 0x00: /* FADD m32real            Add m32real to ST(0) and s.r. in ST(0) */
						  /*
						  i32[0] = readMem(source.addr, SIZE_DWORD);
				                  *fp80 = *fp32 + fpuPop();
				                  if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
				                     fpuPush(*fp80);
				                  }
				                  fpuSetPointers(source.addr, 0xD800 | dest.modrm);
				                  */
                  				break;
					case 0x01: /* FMUL m32real            Multiply ST(0) by m32real and s.r.in ST(0) */
						/*
						*fp80 = *fp32 * fpuPop();
				                  if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
				                     fpuPush(*fp80);
				                  }
				                  fpuSetPointers(source.addr, 0xD800 | dest.modrm);
						*/
						break;
					case 0x02: /* FCOM m32real            Compare ST(0) with m32real. */
						/*
						   i32[0] = readMem(source.addr, SIZE_DWORD);
				                  fpuCompare(fpuGet(0), *fp32);
				                  fpuSetPointers(source.addr, 0xD800 | dest.modrm);
						*/
						break;
					case 0x03: /* FCOMP m32real          Compare ST(0) with m32real,pop r.stack. */
						/*
						          i32[0] = readMem(source.addr, SIZE_DWORD);
					                  dbl = fpuPop();
					                  if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
					                     fpuCompare(dbl, *fp32);
					                  }
					                  fpuSetPointers(source.addr, 0xD800 | dest.modrm);
						*/
						break;
					case 0x04: /* FSUB m32real             Sub m32real from ST(0) and s.r.in ST(0) */
				                  /*
				                  i32[0] = readMem(source.addr, SIZE_DWORD);
				                  *fp80 = fpuPop() - *fp32;
				                  if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
				                     fpuPush(*fp80);
				                  }
				                  fpuSetPointers(source.addr, 0xD800 | dest.modrm);
				                  */
						break;
					case 0x05: /* FSUBR m32real           Sub ST(0) from m32real and s.r.in ST(0) */
						/*
						   i32[0] = readMem(source.addr, SIZE_DWORD);
				                  *fp80 = *fp32 - fpuPop();
				                  if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
				                     fpuPush(*fp80);
				                  }
				                  fpuSetPointers(source.addr, 0xD800 | dest.modrm);
						*/
						break;
					case 0x06: /* FDIV m32real             Divide ST(0) by m32real and s.r.in ST(0) */
						/*
				                   i32[0] = readMem(source.addr, SIZE_DWORD);
				                  *fp80 = fpuPop() / *fp32;
				                  if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
				                     fpuPush(*fp80);
				                  }
				                  fpuSetPointers(source.addr, 0xD800 | dest.modrm);
						*/
						break;
					case 0x07: /* FDIVR m32real           Divide m32real by ST(0) and s.r.in ST(0) */
						/*
						i32[0] = readMem(source.addr, SIZE_DWORD);
				                  *fp80 = *fp32 /fpuPop();
				                  if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
				                     fpuPush(*fp80);
				                  }
				                  fpuSetPointers(source.addr, 0xD800 | dest.modrm);
				                  */
						break;
					case 0xC0: /* FADD ST(0),ST(0)        Add ST(0) to ST(0) and s.r.in ST(0) */
					case 0xC1: /* FADD ST(0),ST(1)        Add ST(0) to ST(1) and s.r.in ST(0) */
					case 0xC2: /* FADD ST(0),ST(2)        Add ST(0) to ST(2) and s.r.in ST(0) */
					case 0xC3: /* FADD ST(0),ST(3)        Add ST(0) to ST(3) and s.r.in ST(0) */
					case 0xC4: /* FADD ST(0),ST(4)        Add ST(0) to ST(4) and s.r.in ST(0) */
					case 0xC5: /* FADD ST(0),ST(5)        Add ST(0) to ST(5) and s.r.in ST(0) */
					case 0xC6: /* FADD ST(0),ST(6)        Add ST(0) to ST(6) and s.r.in ST(0) */
					case 0xC7: /* FADD ST(0),ST(7)        Add ST(0) to ST(7) and s.r.in ST(0) */
					case 0xC8: /* FMUL ST(0),ST(0)        Multiply ST(0) by ST(0) and s.r.in ST(0) */
					case 0xC9: /* FMUL ST(0),ST(1)        Multiply ST(0) by ST(1) and s.r.in ST(0) */
					case 0xCA: /* FMUL ST(0),ST(2)        Multiply ST(0) by ST(2) and s.r.in ST(0) */
					case 0xCB: /* FMUL ST(0),ST(3)        Multiply ST(0) by ST(3) and s.r.in ST(0) */
					case 0xCC: /* FMUL ST(0),ST(4)        Multiply ST(0) by ST(4) and s.r.in ST(0) */
					case 0xCD: /* FMUL ST(0),ST(5)        Multiply ST(0) by ST(5) and s.r.in ST(0) */
					case 0xCE: /* FMUL ST(0),ST(6)        Multiply ST(0) by ST(6) and s.r.in ST(0) */
					case 0xCF: /* FMUL ST(0),ST(7)        Multiply ST(0) by ST(7) and s.r.in ST(0) */
						/*
						 int upper = c->instr.fpu.fpu_modrm & 0xF0;
            					 int lower = c->instr.fpu.fpu_modrm & 0x0F;
						*fp80 = fpuGet(lower & 7);
				                  if (lower < 8) {            //FADD ST(0), ST(i)
				                     *fp80 = fpuPop() + *fp80;
				                  }
				                  else {                      //FMUL ST(0), ST(i)
				                     *fp80 = fpuPop() * *fp80;
				                  }
				                  if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
				                     fpuPush(*fp80);
				                  }
				                  fpuSetPointers(0, 0xD8C0 + lower);
						*/
						
						break;
					case 0xD0: /* FCOM ST(0)               Compare ST(0) with ST(0)  */
					case 0xD1: /* FCOM ST(1)               Compare ST(0) with ST(1)  */
					case 0xD2: /* FCOM ST(2)               Compare ST(0) with ST(2)  */
					case 0xD3: /* FCOM ST(3)               Compare ST(0) with ST(3)  */
					case 0xD4: /* FCOM ST(4)               Compare ST(0) with ST(4)  */
					case 0xD5: /* FCOM ST(5)               Compare ST(0) with ST(5)  */
					case 0xD6: /* FCOM ST(6)               Compare ST(0) with ST(6)  */
					case 0xD7: /* FCOM ST(7)               Compare ST(0) with ST(7)  */
					case 0xD8:  /* FCOMP  ST(0)           Compare ST(0) with ST(0)   */
					case 0xD9: /* FCOMP  ST(1)            Compare ST(0) with ST(1), pop  */
					case 0xDA:  /* FCOMP  ST(2)           Compare ST(0) with ST(2), pop  */
					case 0xDB:  /* FCOMP  ST(3)           Compare ST(0) with ST(3), pop  */
					case 0xDC:  /* FCOMP  ST(4)           Compare ST(0) with ST(4), pop  */
					case 0xDD:  /* FCOMP  ST(5)           Compare ST(0) with ST(5), pop  */
					case 0xDE:  /* FCOMP  ST(6)           Compare ST(0) with ST(6), pop  */
					case 0xDF:  /* FCOMP  ST(7)           Compare ST(0) with ST(7), pop  */
				                  /*
				                   int upper = c->instr.fpu.fpu_modrm & 0xF0;
            					   int lower = c->instr.fpu.fpu_modrm & 0x0F;
				                  *fp80 = fpuGet(lower & 7);
				                  if (lower < 8) {            //FCOM ST(0), ST(i)
				                     fpuCompare(fpuGet(0), *fp80);
				                  }
				                  else {                      //FCOMP ST(0), ST(i)
				                     dbl = fpuPop();
				                     if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
				                        fpuCompare(dbl, *fp80);
				                     }
				                  }
				                  fpuSetPointers(0, 0xD8D0 + lower);
				                  */
						break;
					case 0xE0: /* FSUB ST(0),ST(0)        Sub ST(0) from ST(0) and s.r.in ST(0) */
					case 0xE1:  /* FSUB ST(0),ST(1)        Sub ST(1) from ST(0) and s.r.in ST(0) */					
					case 0xE2: /* FSUB ST(0),ST(2)        Sub ST(2) from ST(0) and s.r.in ST(0) */					
					case 0xE3: /* FSUB ST(0),ST(3)        Sub ST(3) from ST(0) and s.r.in ST(0) */
					case 0xE4: /* FSUB ST(0),ST(4)        Sub ST(4) from ST(0) and s.r.in ST(0) */					
					case 0xE5: /* FSUB ST(0),ST(5)        Sub ST(5) from ST(0) and s.r.in ST(0) */					
					case 0xE6: /* FSUB ST(0),ST(6)        Sub ST(6) from ST(0) and s.r.in ST(0) */					
					case 0xE7: /* FSUB ST(0),ST(7)        Sub ST(7) from ST(0) and s.r.in ST(0) */					
					case 0xE8: /* FSUBR ST(0),ST(0)       Sub ST(0) from ST(0) and s.r.in ST(0) */
					case 0xE9: /* FSUBR ST(0),ST(1)       Sub ST(0) from ST(1) and s.r.in ST(0) */				
					case 0xEA: /* FSUBR ST(0),ST(2)       Sub ST(0) from ST(2) and s.r.in ST(0) */					
					case 0xEB: /* FSUBR ST(0),ST(3)       Sub ST(0) from ST(3) and s.r.in ST(0) */
					case 0xEC: /* FSUBR ST(0),ST(4)       Sub ST(0) from ST(4) and s.r.in ST(0) */					
					case 0xED: /* FSUBR ST(0),ST(5)       Sub ST(0) from ST(5) and s.r.in ST(0) */		
					case 0xEE: /* FSUBR ST(0),ST(6)       Sub ST(0) from ST(6) and s.r.in ST(0) */					
					case 0xEF: /* FSUBR ST(0),ST(7)       Sub ST(0) from ST(7) and s.r.in ST(0) */
						/*
						 int upper = c->instr.fpu.fpu_modrm & 0xF0;
            					 int lower = c->instr.fpu.fpu_modrm & 0x0F;
						*fp80 = fpuGet(lower & 7);
				                  if (lower < 8) {            //FSUB ST(0) / ST(i)
				                     *fp80 = fpuPop() - *fp80;
				                  }
				                  else {            //FSUBR ST(0) / ST(i)
				                     *fp80 = *fp80 - fpuPop();
				                  }
				                  if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
				                     fpuPush(*fp80);
				                  }
				                  fpuSetPointers(0, 0xD8E0 + lower);
				                  */
						break;					
					case 0xF0: /* FDIV ST(0),ST(0)        Divide ST(0) by ST(0) and s.r.in ST(0) */
					case 0xF1: /* FDIV ST(0),ST(1)        Divide ST(0) by ST(1) and s.r.in ST(0) */
					case 0xF2: /* FDIV ST(0),ST(2)        Divide ST(0) by ST(2) and s.r.in ST(0) */
					case 0xF3: /* FDIV ST(0),ST(3)        Divide ST(0) by ST(3) and s.r.in ST(0) */
					case 0xF4: /* FDIV ST(0),ST(4)        Divide ST(0) by ST(4) and s.r.in ST(0) */
					case 0xF5: /* FDIV ST(0),ST(5)        Divide ST(0) by ST(5) and s.r.in ST(0) */
					case 0xF6: /* FDIV ST(0),ST(6)        Divide ST(0) by ST(6) and s.r.in ST(0) */
					case 0xF7: /* FDIV ST(0),ST(7)        Divide ST(0) by ST(7) and s.r.in ST(0) */
					case 0xF8: /* FDIVR ST(0),ST(0)       Divide ST(0) by ST(0) and s.r.in ST(0) */
					case 0xF9: /* FDIVR ST(0),ST(1)       Divide ST(1) by ST(0) and s.r.in ST(0) */
					case 0xFA: /* FDIVR ST(0),ST(2)       Divide ST(2) by ST(0) and s.r.in ST(0) */
					case 0xFB: /* FDIVR ST(0),ST(3)       Divide ST(3) by ST(0) and s.r.in ST(0) */
					case 0xFC: /* FDIVR ST(0),ST(4)       Divide ST(4) by ST(0) and s.r.in ST(0) */
					case 0xFD: /* FDIVR ST(0),ST(5)       Divide ST(5) by ST(0) and s.r.in ST(0) */
					case 0xFE: /* FDIVR ST(0),ST(6)       Divide ST(6) by ST(0) and s.r.in ST(0) */
					case 0xFF: /* FDIVR ST(0),ST(7)       Divide ST(7) by ST(0) and s.r.in ST(0) */
						 /*
						  int upper = c->instr.fpu.fpu_modrm & 0xF0;
				            	  int lower = c->instr.fpu.fpu_modrm & 0x0F;
						 *fp80 = fpuGet(lower & 7);
				                  if (lower < 8) {            //FDIV ST(0) / ST(i)
				                     *fp80 = fpuPop() / *fp80;
				                  }
				                  else {         //FDIVR ST(0) / ST(i)
				                     *fp80 = *fp80 / fpuPop();
				                  }
				                  if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
				                     fpuPush(*fp80);
				                  }
				                  fpuSetPointers(0, 0xD8F0 + lower);
				                  */
						break;										
					default:
						// catch all others to init fpu
						TRACK_INIT_FPU(c->instr, TRACK_FPU_LAST_INSTRUCTION);
						break;
				}
				break;
			case 0xd9: /* FPU Group #2 */
				switch(c->instr.fpu.fpu_modrm) { //All FPU ModRM's
					case 0x00:	/* FLD m32real             Push m32real  */
						/*
						//source.addr is float*
				                  i32[0] = readMem(source.addr, SIZE_DWORD);
				                  fpuPush(*fp32);
				                  fpuSetPointers(source.addr, 0xD900 | dest.modrm);
						*/
						break;
					case 0x02:	/* FST m32real             Copy ST(0) to m32real  */
						/*
						/source.addr is float*
				                  *fp32 = (float)fpuGet(0);
				                  writeMem(source.addr, i32[0], SIZE_DWORD);
				                  fpuSetPointers(source.addr, 0xD900 | dest.modrm);
						*/
						break;
					case 0x03:	/* FSTP m32real            Copy ST(0) to m32real and pop  */
						/*
						   //source.addr is float*
				                  *fp32 = (float)fpuPop();
				                  if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
				                     writeMem(source.addr, i32[0], SIZE_DWORD);
				                  }
				                  fpuSetPointers(source.addr, 0xD900 | dest.modrm);
						*/
						break;
					case 0x04:	/* FLDENV m14/28byte       Load FPU environment from m14/m28 */
						//fpuLoadEnv(source.addr);
						break;
					case 0x05:	/* FLDCW m2byte            Load FPU control word from m2byte */
						/*
						fpu.control = (short)readMem(source.addr, SIZE_WORD);
                  				fpuSetPointers(source.addr, 0xD900 | dest.modrm);
						*/
						break;
					case 0x06:	/* FNSTENV m14/28byte      Store FPU env without */
						//fpuStoreEnv(source.addr);
						break;
					case 0x07:	/* FNSTCW m2byte           Store FPU control word without. writes 2 bytes, not 4 */
						/*
						opsize = SIZE_WORD;
                 				storeOperand(&source, fpu.control);
						*/
						break;
					case 0x30:	/* fnstenv volume 1, page 230 */
						//static int null = 0;
						MEM_DWORD_WRITE(c, c->instr.fpu.ea + 0x00, c->instr.fpu.control);
						MEM_DWORD_WRITE(c, c->instr.fpu.ea + 0x04, c->instr.fpu.status);
						MEM_DWORD_WRITE(c, c->instr.fpu.ea + 0x08, c->instr.fpu.tag);
						MEM_DWORD_WRITE(c, c->instr.fpu.ea + 0x0c, c->last_fpu_instr[1]); //c->instr.fpu.lastIP
						uint32_t value = (c->instr.fpu.lastIPseg | (c->instr.fpu.opcode << 16));
						MEM_DWORD_WRITE(c, c->instr.fpu.ea + 0x10, value);
						MEM_DWORD_WRITE(c, c->instr.fpu.ea + 0x14, c->instr.fpu.lastDataPointer);
						MEM_DWORD_WRITE(c, c->instr.fpu.ea + 0x18, c->instr.fpu.lastDataSeg);
						break;
					case 0xc0: /* FLD ST(0)               Push ST(0)  */
					case 0xc1: /* FLD ST(1)               Push ST(1)  */
					case 0xc2: /* FLD ST(2)               Push ST(2)  */
					case 0xc3: /* FLD ST(3)               Push ST(3)  */
					case 0xc4: /* FLD ST(4)               Push ST(4)  */
					case 0xc5: /* FLD ST(5)               Push ST(5)  */
					case 0xc6: /* FLD ST(6)               Push ST(6)  */
					case 0xc7: /* FLD ST(7)               Push ST(7)  */
					       /*
					       //need implementaiton 
			                       fpuSetPointers(0, 0xD900 | c->instr.fpu.fpu_modrm);
			                       */
						break;
					case 0xc8: /* FXCH ST(0)              Exchange ST(0) and ST(0) */
					case 0xc9: /* FXCH ST(1)              Exchange ST(0) and ST(1) */
					case 0xca: /* FXCH ST(2)              Exchange ST(0) and ST(2) */
					case 0xcb: /* FXCH ST(3)              Exchange ST(0) and ST(3) */
					case 0xcc: /* FXCH ST(4)              Exchange ST(0) and ST(4) */
					case 0xcd: /* FXCH ST(5)              Exchange ST(0) and ST(5) */
					case 0xce: /* FXCH ST(6)              Exchange ST(0) and ST(6) */
					case 0xcf:  /* FXCH ST(7)              Exchange ST(0) and ST(7) */
						/*
						int lower = c->instr.fpu.fpu_modrm & 0x0F;
						if (lower >= 8) {    //FXCH
				                     long double st0 = fpuGet(0);
				                     long double sti = fpuGet(lower & 7);
				                     fpuSet(0, sti);
				                     fpuSet(lower & 7, st0);
				                     fpuSetPointers(0, 0xD900 | c->instr.fpu.fpu_modrm);
				                }
				                */
						break;
					case 0xd0: /* FNOP                    No operation is performed */
						/* 
						fpuSetPointers(0, 0xD900 | c->instr.fpu.fpu_modrm);
						*/
						break;
					case 0xe0: /* FCHS                    Complements sign of ST(0) */
						/*
				                *fp80 = fpuPop();
			                        if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
			                           //if we are masking IE or there is no stack fault
			                           //then complete the operation
			                           fpuPush(fabs(-(*fp80)));
			                        }
			                        fpuSetPointers(0, 0xD9E0);
			                        */
						break;
					case 0xe1: /*  FABS                    Replace ST(0) with its absolute value */
						/*
						*fp80 = fpuPop();
			                        if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
			                           fpuPush(fabs(*fp80));
			                        }
			                        fpuSetPointers(0, 0xD9E1);
			                        */
						break;
					case 0xe4: /* FTST                    Compare ST(0) with 0.0 */
						/*
						fpuCompare(fpuGet(0), 0);
			                        fpuSetPointers(source.addr, 0xD9E4);
			                        */
						break;
					case 0xe5: /* FXAM                    Classify value or number in ST(0) */
						break;
					case 0xe8: /* FLD1                    Push +1.0  */
						/*
						fpuPush(1.0);
			                        fpuSetPointers(0, 0xD9E8);
			                        */
						break;
					case 0xe9: /* FLDL2T                  Push log2 10 */
						/*
						fpuPush(M_LN10 / M_LN2);
			                        fpuSetPointers(0, 0xD9E9);
			                        */
						break;
					case 0xea: /* FLDL2E                  Push log2 e  */
						/*
						fpuPush(M_LOG2E);
			                        fpuSetPointers(0, 0xD9EA);
			                        */
						break;
					case 0xeb: /* FLDPI                   Push pi  */
						/*
						fpuPush(M_PI);
			                        fpuSetPointers(0, 0xD9EB);
			                        */
						break;
					case 0xec: /* FLDLG2                  Push log10 2 */
						/*
						fpuPush(M_LN2 / M_LN10);
			                        fpuSetPointers(0, 0xD9EC);
			                        */
						break;
					case 0xed: /* FLDLN2                  Push loge 2 */
						/*
						fpuPush(M_LN2);
			                        fpuSetPointers(0, 0xD9ED);
			                        */
						break;
					case 0xee: /* FLDZ                    Push +0.0  */
						/*
						fpuPush(0.0);
			                        fpuSetPointers(0, 0xD9EE);
			                        */
						break;
					case 0xf0: /* F2XM1                   Replace ST(0) with 2**ST(0) - 1 */
						break;
					case 0xf1: /* FYL2X                   Replace ST(1) with ST(1)*log2ST(0) and pop */
						break;
					case 0xf2: /* FPTAN                   Replaces ST(0) with its tangent push 1.0 */
					  	/*
					  	*fp80 = fpuPop();
			                        if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
			                           fpuPush(tanl(*fp80));
			                           fpuPush(1.0L);
			                        }
			                        fpuSetPointers(0, 0xD9F2);
			                        */
						break;
					case 0xf3: /*  FPATAN                  Repalces ST(1) with arctan(ST(1)/ST(0)) pop  */
						break;
					case 0xf4: /* FXTRACT                 Seperate value in ST(0) exp. and sig. */
						break;
					case 0xf5: /* FPREM1                  Replaces ST(0) with IEEE rem(ST(0)/ST(1)) */
						/*
						*fp80 = fpuPop();
			                        if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
			                           fpuPush(remainderl(*fp80, fpuGet(0)));
			                        }
			                        fpuSetPointers(0, 0xD9F5);
			                        */
						break;
					case 0xf6: /* FDECSTP                 Decrement TOP field in FPU status word. */
						/*
				        	FPU_CLEAR(FPU_C1);
			                        setFpuStackTop((fpuStackTop - 1) & 7);
			                        fpuSetPointers(0, 0xD9F6);
			                        */
						break;
					case 0xf7: /* FINCSTP                 Increment the TOP field FPU status r. */
						/*
				                FPU_CLEAR(FPU_C1);
			                        setFpuStackTop((fpuStackTop + 1) & 7);
			                        fpuSetPointers(0, 0xD9F7);
			                        */
						break;
					case 0xf8: /* FPREM                   Replaces ST(0) with rem (ST(0)/ST(1)) */
						/*
				                *fp80 = fpuPop();
			                        if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
			                           fpuPush(remainderl(*fp80, fpuGet(0)));
			                        }
			                        fpuSetPointers(0, 0xD9F8);
			                        */
						break;
					case 0xf9: /* FYL2XP1                 Replace ST(1) with ST(1)*log2(ST(0)+1) pop */
						break;
					case 0xfa: /* FSQRT                   square root of ST(0) */
						/*
						*fp80 = fpuPop();
			                        if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
			                           fpuPush(sqrtl(*fp80));
			                        }
			                        fpuSetPointers(0, 0xD9FA);
			                        */
						break;
					case 0xfb: /* FSINCOS                 Compute sine and consine of ST(0) s push c */
						/*
						*fp80 = fpuPop();
			                        if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
			                           fpuPush(sinl(*fp80));
			                           fpuPush(cosl(*fp80));
			                        }
			                        fpuSetPointers(0, 0xD9FB);
			                        */
						break;
					case 0xfc: /* FRNDINT                 Round ST(0) to an integer */
						/*
						*fp80 = fpuPop();
			                        if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
			                           fpuPush(roundl(*fp80));
			                        }
			                        fpuSetPointers(0, 0xD9FC);
			                        */
						break;
					case 0xfd: /* FSCALE                  Scale ST(0) by ST(1) */
						break;
					case 0xfe: /* FSIN                    Replace ST(0) with its sine */
						/*
						*fp80 = fpuPop();
			                        if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
			                           fpuPush(sinl(*fp80));
			                        }
			                        fpuSetPointers(0, 0xD9FE);
			                        */
						break;
					case 0xff: /* FCOS                    Replace ST(0) with its cosine */
						/*
				                *fp80 = fpuPop();
			                        if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
			                           fpuPush(cosl(*fp80));
			                        }
			                        fpuSetPointers(0, 0xD9FF);
			                        */
						break;
					default:
						// catch all others to init fpu
						TRACK_INIT_FPU(c->instr, TRACK_FPU_LAST_INSTRUCTION);
						break;
				}
				break;
			case 0xda:  /* FPU Group #3 */
				switch(c->instr.fpu.fpu_modrm) { //All FPU ModRM's
					case 0x00:	/* FIADD m32int            Add m32int to ST(0) and s.r.in ST(0) */
						
						/*
						   //source.addr is int*
						   i32[0] = readMem(source.addr, SIZE_DWORD);
				                  *fp80 = i32[0] + fpuPop();
				                  if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
				                     fpuPush(*fp80);
				                  }
				                  fpuSetPointers(source.addr, 0xDA00 | dest.modrm);
						*/
						break;
					case 0x01:	/* FIMUL m32int            Multiply ST(0) by m32int and s.r.in ST(0) */
						/*
						  //source.addr is int*
				                  i32[0] = readMem(source.addr, SIZE_DWORD);
				                  *fp80 = i32[0] * fpuPop();
				                  if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
				                     fpuPush(*fp80);
				                  }
				                  fpuSetPointers(source.addr, 0xDA00 | dest.modrm);
						*/
						break;
					case 0x02:	/* FICOM m32int            Compare ST(0) with m32int */
						/*
						  //source.addr is int*
				                  i32[0] = readMem(source.addr, SIZE_DWORD);
				                  fpuCompare(fpuGet(0), *i32);
				                  fpuSetPointers(source.addr, 0xDA00 | dest.modrm);
						*/
						break;
					case 0x03:	/* FICOMP m32int           Compare ST(0) with m32int and pop  */
						/*
						   //source.addr is int*
						   i32[0] = readMem(source.addr, SIZE_DWORD);
				                  dbl = fpuPop();
				                  if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
				                     fpuCompare(dbl, *i32);
				                  }
				                  fpuSetPointers(source.addr, 0xDA00 | dest.modrm);
						*/
						break;
					case 0x04:	/* FISUB m32int            Sub m32int from ST(0) and s.r.in ST(0) */
						/*
						//source.addr is int*
						   i32[0] = readMem(source.addr, SIZE_DWORD);
				                  *fp80 = fpuPop() - i32[0];
				                  if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
				                     fpuPush(*fp80);
				                  }
				                  fpuSetPointers(source.addr, 0xDA00 | dest.modrm);
						*/
						break;
					case 0x05:	/* FISUBR m32int           Sub ST(0) from m32int and s.r.in ST(0) */
						/*
						  //source.addr is int*
						   i32[0] = readMem(source.addr, SIZE_DWORD);
				                  *fp80 = i32[0] - fpuPop();
				                  if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
				                     fpuPush(*fp80);
				                  }
				                  fpuSetPointers(source.addr, 0xDA00 | dest.modrm);
						*/
						break;
					case 0x06:	/* FIDIV m32int            Divide ST(0) by m32int and s.r.in ST(0) */
						/*
						   //source.addr is int*
						   i32[0] = readMem(source.addr, SIZE_DWORD);
				                  *fp80 = fpuPop() / i32[0];
				                  if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
				                     fpuPush(*fp80);
				                  }
				                  fpuSetPointers(source.addr, 0xDA00 | dest.modrm);
						*/
						break;
					case 0x07:	/* FIDIVR m32int           Divide m32int by ST(0) and s.r.in ST(0) */
						/*
						   //source.addr is int*
						   i32[0] = readMem(source.addr, SIZE_DWORD);
				                  *fp80 = i32[0] / fpuPop();
				                  if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
				                     fpuPush(*fp80);
				                  }
				                  fpuSetPointers(source.addr, 0xDA00 | dest.modrm);
						*/
						break;
					case 0xc0:	/* FCMOVB ST(0),ST(0)      Move if below  */
					case 0xc1:	/* FCMOVB ST(0),ST(1)      Move if below  */
					case 0xc2:	/* FCMOVB ST(0),ST(2)      Move if below  */
					case 0xc3:	/* FCMOVB ST(0),ST(3)      Move if below  */
					case 0xc4:	/* FCMOVB ST(0),ST(4)      Move if below  */
					case 0xc5:	/* FCMOVB ST(0),ST(5)      Move if below  */
					case 0xc6:	/* FCMOVB ST(0),ST(6)      Move if below  */
					case 0xc7:	/* FCMOVB ST(0),ST(7)      Move if below  */
						/*
						//*** need implementation
                 				fpuSetPointers(source.addr, 0xDA00 | dest.modrm);
                 				*/
						break;
					case 0xc8:	/* FCMOVE ST(0),ST(0)      Move if equal  */
					case 0xc9:	/* FCMOVE ST(0),ST(1)      Move if equal  */
					case 0xca:	/* FCMOVE ST(0),ST(2)      Move if equal  */
					case 0xcb:	/* FCMOVE ST(0),ST(3)      Move if equal  */
					case 0xcc:	/* FCMOVE ST(0),ST(4)      Move if equal  */
					case 0xcd:	/* FCMOVE ST(0),ST(5)      Move if equal  */
					case 0xce:	/* FCMOVE ST(0),ST(6)      Move if equal  */
					case 0xcf:	/* FCMOVE ST(0),ST(7)      Move if equal  */
						/*
						//*** need implementation
                  				fpuSetPointers(source.addr, 0xDA00 | dest.modrm);
                  				*/
						break;
					case 0xd0:	/* FCMOVBE ST(0),ST(0)     Move if below or equal  */
					case 0xd1:	/* FCMOVBE ST(0),ST(1)     Move if below or equal  */
					case 0xd2:	/* FCMOVBE ST(0),ST(2)     Move if below or equal  */
					case 0xd3:	/* FCMOVBE ST(0),ST(3)     Move if below or equal  */
					case 0xd4:	/* FCMOVBE ST(0),ST(4)     Move if below or equal  */
					case 0xd5:	/* FCMOVBE ST(0),ST(5)     Move if below or equal  */
					case 0xd6:	/* FCMOVBE ST(0),ST(6)     Move if below or equal  */
					case 0xd7:	/* FCMOVBE ST(0),ST(7)     Move if below or equal  */
						/*
						//*** need implementation
                  				fpuSetPointers(source.addr, 0xDA00 | dest.modrm);
                  				*/
						break;
					case 0xd8:	/* FCMOVU ST(0),ST(0)      Move if unordered */
					case 0xd9:	/* FCMOVU ST(0),ST(1)      Move if unordered  */
					case 0xda:	/* FCMOVU ST(0),ST(2)      Move if unordered  */											
					case 0xdb:	/* FCMOVU ST(0),ST(3)      Move if unordered  */
					case 0xdc:	/* FCMOVU ST(0),ST(4)      Move if unordered  */
					case 0xdd:	/* FCMOVU ST(0),ST(5)      Move if unordered  */
					case 0xde:	/* FCMOVU ST(0),ST(6)      Move if unordered  */
					case 0xdf:	/* FCMOVU ST(0),ST(7)      Move if unordered  */
						/*
						//*** need implementation
                  				fpuSetPointers(source.addr, 0xDA00 | dest.modrm);
                  				*/
						break;
					case 0xe9:	/* FUCOMPP                 Compare ST(0) with ST(1) and pop pop */
						/*
						//*** need implementation
                  				fpuSetPointers(source.addr, 0xDA00 | dest.modrm);
                  				*/
						break;
					default:
						// catch all others to init fpu
						TRACK_INIT_FPU(c->instr, TRACK_FPU_LAST_INSTRUCTION);
						break;
									
				}
				break;
			case 0xdb:  /* FPU Group #4 */
				switch(c->instr.fpu.fpu_modrm) { //All FPU ModRM's
					case 0x00:	/* FILD m32int             Push m32int  */
						/*
							//source.addr is int*
					                  i32[0] = readMem(source.addr, SIZE_DWORD);
					                  if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
					                     fpuPush(i32[0]);
					                  }
					                  fpuSetPointers(source.addr, 0xDB00 | dest.modrm);
						*/
						break;
					case 0x01:	/* FISTTP m32int, ST(0)    Store Integer with Truncation and Pop */
						/*
				                   //source.addr is int*
				                  *i32 = (int)fpuPop();
				                  if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
				                     writeMem(source.addr, i32[0], SIZE_DWORD);
				                  }
				                  fpuSetPointers(source.addr, 0xDB00 | dest.modrm);
						*/
						break;
					case 0x02:	/* FIST m32int             Store ST(0) in m32int */
						/*
						   //source.addr is int*
				                  *i32 = (int)fpuGet(0);
				                  writeMem(source.addr, i32[0], SIZE_DWORD);
				                  fpuSetPointers(source.addr, 0xDB00 | dest.modrm);
						*/
						break;
					case 0x03:	/* FISTP m32int            Store ST(0) in m32int and pop  */
						/*
						          //source.addr is int*
					                  *i32 = (int)fpuPop();
					                  if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
					                     writeMem(source.addr, i32[0], SIZE_DWORD);
					                  }
					                  fpuSetPointers(source.addr, 0xDB00 | dest.modrm);
						*/
						break;
					case 0x05:	/* FLD m80real             Push m80real */
						/*
							  //source.addr is long double*
					                  i32[0] = readMem(source.addr, SIZE_DWORD);
					                  i32[1] = readMem(source.addr + 4, SIZE_DWORD);
					                  i32[2] = readMem(source.addr + 8, SIZE_WORD);
					                  fpuPush(*fp80);
					                  fpuSetPointers(source.addr, 0xDB00 | dest.modrm);
						*/
						break;
					case 0x07:	/* FSTP m80real            Copy ST(0) to m80real and pop  */
						/*
							  //source.addr is long double*
					                  *fp80 = fpuPop();
					                  if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
					                     writeMem(source.addr, i32[0], SIZE_DWORD);
					                     writeMem(source.addr + 4, i32[1], SIZE_DWORD);
					                     writeMem(source.addr + 8, i32[2], SIZE_WORD);
					                  }
					                  fpuSetPointers(source.addr, 0xDB00 | dest.modrm);
						*/
						break;
					case 0xc0:	/* FCMOVNB ST(0),ST(0)     Move if not below */
					case 0xc1:	/* FCMOVNB ST(0),ST(1)     Move if not below  */
					case 0xc2:	/* FCMOVNB ST(0),ST(2)     Move if not below  */
					case 0xc3:	/* FCMOVNB ST(0),ST(3)     Move if not below  */
					case 0xc4:	/* FCMOVNB ST(0),ST(4)     Move if not below  */
					case 0xc5:	/* FCMOVNB ST(0),ST(5)     Move if not below  */
					case 0xc6:	/* FCMOVNB ST(0),ST(6)     Move if not below  */
					case 0xc7:	/* FCMOVNB ST(0),ST(7)     Move if not below  */
						/*
							//*** need implementation
                  					fpuSetPointers(0, 0xDB00 | dest.modrm);
						*/
						break;
					case 0xc8:	/* FCMOVNE ST(0),ST(0)     Move if not equal  */
					case 0xc9:	/* FCMOVNE ST(0),ST(1)     Move if not equal  */
					case 0xca:	/* FCMOVNE ST(0),ST(2)     Move if not equal  */
					case 0xcb:	/* FCMOVNE ST(0),ST(3)     Move if not equal  */
					case 0xcc:	/* FCMOVNE ST(0),ST(4)     Move if not equal  */
					case 0xcd:	/* FCMOVNE ST(0),ST(5)     Move if not equal  */
					case 0xce:	/* FCMOVNE ST(0),ST(6)     Move if not equal  */
					case 0xcf:	/* FCMOVNE ST(0),ST(7)     Move if not equal  */
						/*
							//*** need implementation
                  					fpuSetPointers(0, 0xDB00 | dest.modrm);
						*/
						break;
					case 0xd0:	/* FCMOVNBE ST(0),ST(0)    Move if not below or equal */
					case 0xd1:	/* FCMOVNBE ST(0),ST(1)    Move if not below or equal */
					case 0xd2:	/* FCMOVNBE ST(0),ST(2)    Move if not below or equal */
					case 0xd3:	/* FCMOVNBE ST(0),ST(3)    Move if not below or equal */
					case 0xd4:	/* FCMOVNBE ST(0),ST(4)    Move if not below or equal */
					case 0xd5:	/* FCMOVNBE ST(0),ST(5)    Move if not below or equal */
					case 0xd6:	/* FCMOVNBE ST(0),ST(6)    Move if not below or equal */
					case 0xd7:	/* FCMOVNBE ST(0),ST(7)    Move if not below or equal */
						/*
							//*** need implementation
                  					fpuSetPointers(0, 0xDB00 | dest.modrm);
						*/
						break;
					case 0xd8:	/* FCMOVNU ST(0),ST(0)     Move if not unordered  */
					case 0xd9:	/* FCMOVNU ST(0),ST(1)     Move if not unordered  */
					case 0xda:	/* FCMOVNU ST(0),ST(2)     Move if not unordered  */
					case 0xdb:	/* FCMOVNU ST(0),ST(3)     Move if not unordered  */
					case 0xdc:	/* FCMOVNU ST(0),ST(4)     Move if not unordered  */
					case 0xdd:	/* FCMOVNU ST(0),ST(5)     Move if not unordered  */
					case 0xde:	/* FCMOVNU ST(0),ST(6)     Move if not unordered  */
					case 0xdf:	/* FCMOVNU ST(0),ST(7)     Move if not unordered  */
						/*
							//*** need implementation
                  					fpuSetPointers(0, 0xDB00 | dest.modrm);
						*/
						break;
					case 0xe0:	/* FNENI                    Treated as Integer NOP  */
						break;
					case 0xe1:	/* FNDISI                  Treated as Integer NOP */
						break;
					case 0xe2:	/* FNCLEX                  Clear f.e.f. without checking for .. */
						/*
							fpu.status &= 0x7F00;
						*/
						break;
					case 0xe3:	/* FNINIT                  Initialize FPU without ... */
						/*
							fpuInit();
						*/
						break;
					case 0xe8:	/* FUCOMI ST(0), ST(0)         Compare ST(0) with ST(0), check o.v.set s.f. */
					case 0xe9:	/* FUCOMI ST(0), ST(1)         Compare ST(0) with ST(1), check o.v.set s.f. */
					case 0xea:	/* FUCOMI ST(0), ST(2)         Compare ST(0) with ST(2), check o.v.set s.f. */
					case 0xeb:	/* FUCOMI ST(0), ST(3)         Compare ST(0) with ST(3), check o.v.set s.f. */
					case 0xec:	/* FUCOMI ST(0), ST(4)         Compare ST(0) with ST(4), check o.v.set s.f. */
					case 0xed:	/* FUCOMI ST(0), ST(5)         Compare ST(0) with ST(5), check o.v.set s.f. */
					case 0xee:	/* FUCOMI ST(0), ST(6)         Compare ST(0) with ST(6), check o.v.set s.f. */
					case 0xef:	/* FUCOMI ST(0), ST(7)         Compare ST(0) with ST(7), check o.v.set s.f. */
						/*
						      //*** need implementation
				                     fpuSetPointers(0, 0xDB00 | dest.modrm);
						*/
						break;
					case 0xf0:	/* FCOMI ST(0), ST(0)          Compare ST(0) with ST(0), set status flags */
					case 0xf1:	/* FCOMI ST(0), ST(1)          Compare ST(0) with ST(1), set status flags */
					case 0xf2:	/* FCOMI ST(0), ST(2)          Compare ST(0) with ST(2), set status flags */
					case 0xf3:	/* FCOMI ST(0), ST(3)          Compare ST(0) with ST(3), set status flags */
					case 0xf4:	/* FCOMI ST(0), ST(4)          Compare ST(0) with ST(4), set status flags */
					case 0xf5:	/* FCOMI ST(0), ST(5)          Compare ST(0) with ST(5), set status flags */
					case 0xf6:	/* FCOMI ST(0), ST(6)          Compare ST(0) with ST(6), set status flags */
					case 0xf7:	/* FCOMI ST(0), ST(7)          Compare ST(0) with ST(7), set status flags */
						/*
							//*** need implementation
	                  				fpuSetPointers(0, 0xDB00 | dest.modrm);
                  				*/
						break;
					default:
						// catch all others to init fpu
						TRACK_INIT_FPU(c->instr, TRACK_FPU_LAST_INSTRUCTION);
						break;
				}
				break;
			case 0xdc:  /* FPU Group #5 */
				switch(c->instr.fpu.fpu_modrm) { //All FPU ModRM's
					case 0x00:	/* FADD m64real            Add m64real to ST(0) and s.r.in ST(0) */
						/*
						    //source.addr is double*
					                  i32[0] = readMem(source.addr, SIZE_DWORD);
					                  i32[1] = readMem(source.addr + 4, SIZE_DWORD);
					                  *fp80 = fpuPop() + *fp64;
					                  if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
					                     fpuPush(*fp80);
					                  }
					                  fpuSetPointers(source.addr, 0xDC00 | dest.modrm);
						*/
						break;
					case 0x01:	/* FMUL m64real            Multiply ST(0) by m64real and s.r.in ST(0) */
						/*
						    //source.addr is double*
							i32[0] = readMem(source.addr, SIZE_DWORD);
					                  i32[1] = readMem(source.addr + 4, SIZE_DWORD);
					                  *fp80 = fpuPop() * *fp64;
					                  if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
					                     fpuPush(*fp80);
					                  }
					                  fpuSetPointers(source.addr, 0xDC00 | dest.modrm);
						*/
						break;
					case 0x02:	/* FCOM m64real            Compare ST(0) with m64real. */
						/*
						    //source.addr is double*
				                  i32[0] = readMem(source.addr, SIZE_DWORD);
				                  i32[1] = readMem(source.addr + 4, SIZE_DWORD);
				                  fpuCompare(fpuGet(0), *fp64);
				                  fpuSetPointers(source.addr, 0xDC00 | dest.modrm);
						*/
						break;
					case 0x03:	/* FCOMP m64real           Compare ST(0) with m64real,pop r.stack. */
						/*
						    //source.addr is double*
				                  i32[0] = readMem(source.addr, SIZE_DWORD);
				                  i32[1] = readMem(source.addr + 4, SIZE_DWORD);
				                  dbl = fpuPop();
				                  if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
				                     fpuCompare(dbl, *fp64);
				                  }
				                  fpuSetPointers(source.addr, 0xD800 | dest.modrm);
						*/
						break;
					case 0x04:	/* FSUB m64real            Sub m64real from ST(0) and s.r.in ST(0) */
						/*
						    //source.addr is double*
				                  i32[0] = readMem(source.addr, SIZE_DWORD);
				                  i32[1] = readMem(source.addr + 4, SIZE_DWORD);
				                  *fp80 = fpuPop() - *fp64;
				                  if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
				                     fpuPush(*fp80);
				                  }
				                  fpuSetPointers(source.addr, 0xDC00 | dest.modrm);
						*/
						break;
					case 0x05:	/* FSUBR m64real           Sub ST(0) from m64real and s.r.in ST(0) */
						/*
						    //source.addr is double*
				                  i32[0] = readMem(source.addr, SIZE_DWORD);
				                  i32[1] = readMem(source.addr + 4, SIZE_DWORD);
				                  *fp80 = *fp64 - fpuPop();
				                  if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
				                     fpuPush(*fp80);
				                  }
				                  fpuSetPointers(source.addr, 0xDC00 | dest.modrm);
						*/
						break;
					case 0x06:	/* FDIV m64real            Divide ST(0) by m64real and s.r.in ST(0) */
						/*
						    //source.addr is double*
				                  i32[0] = readMem(source.addr, SIZE_DWORD);
				                  i32[1] = readMem(source.addr + 4, SIZE_DWORD);
				                  *fp80 = fpuPop() / *fp64;
				                  if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
				                     fpuPush(*fp80);
				                  }
				                  fpuSetPointers(source.addr, 0xDC00 | dest.modrm);
						*/
						break;
					case 0x07:	/* FDIVR m64real           Divide m64real by ST(0) and s.r.in ST(0) */
						/*
						    //source.addr is double*
				                  i32[0] = readMem(source.addr, SIZE_DWORD);
				                  i32[1] = readMem(source.addr + 4, SIZE_DWORD);
				                  *fp80 = *fp64/ fpuPop();
				                  if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
				                     fpuPush(*fp80);
				                  }
				                  fpuSetPointers(source.addr, 0xDC00 | dest.modrm);
						*/
						break;
					case 0xc0:	/* FADD ST(0),ST(0)        Add ST(0) to ST(0) and s.r. in ST(0) */
					case 0xc1:	/* FADD ST(1),ST(0)        Add ST(1) to ST(0) and s.r. in ST(1) */
					case 0xc2:	/* FADD ST(2),ST(0)        Add ST(2) to ST(0) and s.r. in ST(2) */
					case 0xc3:	/* FADD ST(3),ST(0)        Add ST(3) to ST(0) and s.r. in ST(3) */
					case 0xc4:	/* FADD ST(4),ST(0)        Add ST(4) to ST(0) and s.r. in ST(4) */
					case 0xc5:	/* FADD ST(5),ST(0)        Add ST(5) to ST(0) and s.r. in ST(5) */
					case 0xc6:	/* FADD ST(6),ST(0)        Add ST(6) to ST(0) and s.r. in ST(6) */
					case 0xc7:	/* FADD ST(7),ST(0)        Add ST(7) to ST(0) and s.r. in ST(7) */
					case 0xc8:	/* FMUL ST(0),ST(0)        Multiply ST(0) by ST(0) and s.r.in ST(0) */
					case 0xc9:	/* FMUL ST(1),ST(0)        Multiply ST(1) by ST(0) and s.r.in ST(1) */
					case 0xca:	/* FMUL ST(2),ST(0)        Multiply ST(2) by ST(0) and s.r.in ST(2) */
					case 0xcb:	/* FMUL ST(3),ST(0)        Multiply ST(3) by ST(0) and s.r.in ST(3) */
					case 0xcc:	/* FMUL ST(4),ST(0)        Multiply ST(4) by ST(0) and s.r.in ST(4) */
					case 0xcd:	/* FMUL ST(5),ST(0)        Multiply ST(5) by ST(0) and s.r.in ST(5) */
					case 0xce:	/* FMUL ST(6),ST(0)        Multiply ST(6) by ST(0) and s.r.in ST(6) */
					case 0xcf:	/* FMUL ST(7),ST(0)        Multiply ST(7) by ST(0) and s.r.in ST(7) */
						/*
						int lower = c->instr.fpu.fpu_modrm & 0x0F;
						*fp80 = fpuGet(lower & 7);
				                  if (lower < 8) {           //FADD  ST(i), ST(0)
				                     *fp80 = *fp80 + fpuGet(0);
				                  }
				                  else {            //FMUL  ST(i), ST(0)
				                     *fp80 = *fp80 * fpuGet(0);
				                  }
				                  fpuSet(lower & 7, *fp80);
				                  fpuSetPointers(0, 0xDCC0 + lower);
				                  */
				                  break;
			                  case 0xe0: 	/* FSUBR ST(0),ST(0)       Sub ST(0) from ST(0) and s.r.in ST(0) */
			                  case 0xe1: 	/* FSUBR ST(1),ST(0)       Sub ST(1) from ST(0) and s.r.in ST(1) */
			                  case 0xe2: 	/* FSUBR ST(2),ST(0)       Sub ST(2) from ST(0) and s.r.in ST(2) */
			                  case 0xe3: 	/* FSUBR ST(3),ST(0)       Sub ST(3) from ST(0) and s.r.in ST(3) */
			                  case 0xe4: 	/* FSUBR ST(4),ST(0)       Sub ST(4) from ST(0) and s.r.in ST(4) */
			                  case 0xe5: 	/* FSUBR ST(5),ST(0)       Sub ST(5) from ST(0) and s.r.in ST(5) */
			                  case 0xe6: 	/* FSUBR ST(6),ST(0)       Sub ST(6) from ST(0) and s.r.in ST(6) */
			                  case 0xe7: 	/* FSUBR ST(7),ST(0)       Sub ST(7) from ST(0) and s.r.in ST(7) */
			                  case 0xe8:	/* FSUB ST(0),ST(0)        Sub ST(0) from ST(0) and s.r.in ST(0) */
			                  case 0xe9:	/* FSUB ST(1),ST(0)        Sub ST(0) from ST(1) and s.r.in ST(1) */
			                  case 0xea:	/* FSUB ST(2),ST(0)        Sub ST(0) from ST(2) and s.r.in ST(2) */
			                  case 0xeb:	/* FSUB ST(3),ST(0)        Sub ST(0) from ST(3) and s.r.in ST(3) */
			                  case 0xec:	/* FSUB ST(4),ST(0)        Sub ST(0) from ST(4) and s.r.in ST(4) */
			                  case 0xed:	/* FSUB ST(5),ST(0)        Sub ST(0) from ST(5) and s.r.in ST(5) */
			                  case 0xee:	/* FSUB ST(6),ST(0)        Sub ST(0) from ST(6) and s.r.in ST(6) */
			                  case 0xef:	/* FSUB ST(7),ST(0)        Sub ST(0) from ST(7) and s.r.in ST(7) */
						 /*
						 int lower = c->instr.fpu.fpu_modrm & 0x0F;
						*fp80 = fpuGet(lower & 7);
				                  if (lower >= 8) {           //FSUB  ST(i), ST(0)
				                     *fp80 = *fp80 - fpuGet(0);
				                  }
				                  else {                     //FSUBR  ST(i), ST(0)
				                     *fp80 = fpuGet(0) - *fp80;
				                  }
				                  fpuSet(lower & 7, *fp80);
				                  fpuSetPointers(0, 0xDCE0 + lower);
				                  */
	                  			break;
                  			case 0xf0:	/* FDIVR ST(0),ST(0)       Divide ST(0) by ST(0) and s.r.in ST(0) */
                  			case 0xf1:	/* FDIVR ST(1),ST(0)       Divide ST(0) by ST(1) and s.r.in ST(1) */
                  			case 0xf2:	/* FDIVR ST(2),ST(0)       Divide ST(0) by ST(2) and s.r.in ST(2) */
                  			case 0xf3:	/* FDIVR ST(3),ST(0)       Divide ST(0) by ST(3) and s.r.in ST(3) */
                  			case 0xf4:	/* FDIVR ST(4),ST(0)       Divide ST(0) by ST(4) and s.r.in ST(4) */
                  			case 0xf5:	/* FDIVR ST(5),ST(0)       Divide ST(0) by ST(5) and s.r.in ST(5) */
                  			case 0xf6:	/* FDIVR ST(6),ST(0)       Divide ST(0) by ST(6) and s.r.in ST(6) */
                  			case 0xf7:	/* FDIVR ST(7),ST(0)       Divide ST(0) by ST(7) and s.r.in ST(7) */
                  			case 0xf8:	/* FDIV ST(0),ST(0)        Divide ST(0) by ST(0) and s.r.in ST(0) */
                  			case 0xf9:	/* FDIV ST(1),ST(0)        Divide ST(1) by ST(0) and s.r.in ST(1) */
                  			case 0xfa:	/* FDIV ST(2),ST(0)        Divide ST(2) by ST(0) and s.r.in ST(2) */
                  			case 0xfb:	/* FDIV ST(3),ST(0)        Divide ST(3) by ST(0) and s.r.in ST(3) */
                  			case 0xfc:	/* FDIV ST(4),ST(0)        Divide ST(4) by ST(0) and s.r.in ST(4) */
                  			case 0xfd:	/* FDIV ST(5),ST(0)        Divide ST(5) by ST(0) and s.r.in ST(5) */
                  			case 0xfe:	/* FDIV ST(6),ST(0)        Divide ST(6) by ST(0) and s.r.in ST(6) */
                  			case 0xff:	/* FDIV ST(7),ST(0)        Divide ST(7) by ST(0) and s.r.in ST(7) */
				                /*
				                 int lower = c->instr.fpu.fpu_modrm & 0x0F;
				                *fp80 = fpuGet(lower & 7);
				                if (lower >= 8) {           //FDIV  ST(i), ST(0)
				                   *fp80 = *fp80 / fpuGet(0);
				                } else {                     //FDIVR  ST(i), ST(0)
				                   *fp80 = fpuGet(0) / *fp80;
				                }
				                fpuSet(lower & 7, *fp80);
				                fpuSetPointers(0, 0xDCF0 + lower);
				                */
                  				break;
                  			default:
						// catch all others to init fpu
						TRACK_INIT_FPU(c->instr, TRACK_FPU_LAST_INSTRUCTION);
						break;
				}
				break;
			case 0xdd:  /* FPU Group #6 */
				switch(c->instr.fpu.fpu_modrm) { //All FPU ModRM's
					case 0x00:	/* FLD m64real             Push m64real */
						/*
							//source.addr is double*
					                  i32[0] = readMem(source.addr, SIZE_DWORD);
					                  i32[1] = readMem(source.addr + 4, SIZE_DWORD);
					                  if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
					                     fpuPush(*fp64);
					                  }
					                  fpuSetPointers(source.addr, 0xDD00 | dest.modrm);
						*/
						break;
					case 0x01:	/* FISTTP m64int, ST(0)             Store Integer with Truncation and Pop */
						/*
							*i64 = (quad)fpuPop();
					                  if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
					                     writeMem(source.addr, i32[0], SIZE_DWORD);
					                     writeMem(source.addr + 4, i32[1], SIZE_DWORD);
					                  }
					                  fpuSetPointers(source.addr, 0xDD00 | dest.modrm);
						*/
						break;
					case 0x02:	/* FST m64real             Copy ST(0) to m64real */
						/*
							//source.addr is double*
					                  *fp64 = (double)fpuGet(0);
					                  writeMem(source.addr, i32[0], SIZE_DWORD);
					                  writeMem(source.addr + 4, i32[1], SIZE_DWORD);
					                  fpuSetPointers(source.addr, 0xDD00 | dest.modrm);
						*/
						break;
					case 0x03:	/* FSTP m64real            Copy ST(0) to m64real and pop  */
						/*
							   //source.addr is double*
					                  *fp64 = (double)fpuPop();
					                  if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
					                     writeMem(source.addr, i32[0], SIZE_DWORD);
					                     writeMem(source.addr + 4, i32[1], SIZE_DWORD);
					                  }
					                  fpuSetPointers(source.addr, 0xDD00 | dest.modrm);
						*/
						break;
					case 0x04:	/* FRSTOR m94/108byte      Load FPU status from m94 or m108 byte  */
						/*
						                  fpuLoadEnv(source.addr);
						                  source.addr += 28;
						                  for (int m = 0; m < 8; m++) {
						                     unsigned short *s = (unsigned short*)&fpu.r[m];
						                     for (int n = 0; n < 5; n++) {
						                        s[n] = readMem(source.addr, SIZE_WORD);
						                        source.addr += 2;
						                     }
						                  }
						*/
						break;
					case 0x05:	/* fnstw (fake opcode?) */
						//should not happen
						break;
					case 0x06:	/* FNSAVE m94/108byte      Store FPU environment to m94 or m108 */
						/*
							fpuStoreEnv(source.addr);
					                  source.addr += 28;
					                  for (int m = 0; m < 8; m++) {
					                     unsigned short *s = (unsigned short*)&fpu.r[m];
					                     for (int n = 0; n < 5; n++) {
					                        writeMem(source.addr, s[n], SIZE_WORD);
					                        source.addr += 2;
					                     }
					                  }
						*/
						break;
					case 0x07:	/* FNSTSW m2byte           Store FPU status word at m2byte without  */
						/*
							opsize = SIZE_WORD;
                 					 storeOperand(&source, fpu.status);
						*/
						break;
					case 0xc0:	/* FFREE ST(0)             Sets tag for ST(0) to empty */
					case 0xc1:	/* FFREE ST(1)             Sets tag for ST(1) to empty */
					case 0xc2:	/* FFREE ST(2)             Sets tag for ST(2) to empty */
					case 0xc3:	/* FFREE ST(3)             Sets tag for ST(3) to empty */
					case 0xc4:	/* FFREE ST(4)             Sets tag for ST(4) to empty */
					case 0xc5:	/* FFREE ST(5)             Sets tag for ST(5) to empty */
					case 0xc6:	/* FFREE ST(6)             Sets tag for ST(6) to empty */
					case 0xc7:	/* FFREE ST(7)             Sets tag for ST(7) to empty */
						/*
						int lower = c->instr.fpu.fpu_modrm & 0x0F;
						if (lower < 8) {
				                     fpuSetTag(lower, FPU_EMPTY_TAG);
				                     fpuSetPointers(0, 0xDDC0 + lower);
				                }
				                */
						break;
					case 0xd0:	/* FST ST(0)               Copy ST(0) to ST(0) */
					case 0xd1:	/* FST ST(1)               Copy ST(0) to ST(1) */
					case 0xd2:	/* FST ST(2)               Copy ST(0) to ST(2) */
					case 0xd3:	/* FST ST(3)               Copy ST(0) to ST(3) */
					case 0xd4:	/* FST ST(4)               Copy ST(0) to ST(4) */
					case 0xd5:	/* FST ST(5)               Copy ST(0) to ST(5) */
					case 0xd6:	/* FST ST(6)               Copy ST(0) to ST(6) */
					case 0xd7:	/* FST ST(7)               Copy ST(0) to ST(7) */
						/*
							//*** need implementation
                  					fpuSetPointers(0, 0xDD00 | dest.modrm);
						*/
						break;
					case 0xd8:	/* FSTP ST(0)              Copy ST(0) to ST(0) and pop  */
					case 0xd9:	/* FSTP ST(1)              Copy ST(0) to ST(1) and pop  */
					case 0xda:	/* FSTP ST(2)              Copy ST(0) to ST(2) and pop  */
					case 0xdb:	/* FSTP ST(3)              Copy ST(0) to ST(3) and pop  */
					case 0xdc:	/* FSTP ST(4)              Copy ST(0) to ST(4) and pop  */
					case 0xdd:	/* FSTP ST(5)              Copy ST(0) to ST(5) and pop  */
					case 0xde:	/* FSTP ST(6)              Copy ST(0) to ST(6) and pop  */
					case 0xdf:	/* FSTP ST(7)              Copy ST(0) to ST(7) and pop  */
						/*
						//*** need implementation
                  				fpuSetPointers(0, 0xDD00 | dest.modrm);
                  				*/
						break;
					case 0xe0: 	/* FUCOM ST(0)             Compare ST(0) with ST(0) */
					case 0xe1: 	/* FUCOM ST(1)             Compare ST(0) with ST(1) */
					case 0xe2: 	/* FUCOM ST(2)             Compare ST(0) with ST(2) */
					case 0xe3: 	/* FUCOM ST(3)             Compare ST(0) with ST(3) */
					case 0xe4: 	/* FUCOM ST(4)             Compare ST(0) with ST(4) */
					case 0xe5: 	/* FUCOM ST(5)             Compare ST(0) with ST(5) */
					case 0xe6: 	/* FUCOM ST(6)             Compare ST(0) with ST(6) */
					case 0xe7: 	/* FUCOM ST(7)             Compare ST(0) with ST(7) */
						/*
						//*** need implementation
                  				fpuSetPointers(0, 0xDD00 | dest.modrm);
                  				*/
						break;
					case 0xe8:	/* FUCOMP ST(0)            Compare ST(0) with ST(0) and pop  */
					case 0xe9:	/* FUCOMP ST(1)            Compare ST(0) with ST(1) and pop  */
					case 0xea:	/* FUCOMP ST(2)            Compare ST(0) with ST(2) and pop  */
					case 0xeb:	/* FUCOMP ST(3)            Compare ST(0) with ST(3) and pop  */
					case 0xec:	/* FUCOMP ST(4)            Compare ST(0) with ST(4) and pop  */
					case 0xed:	/* FUCOMP ST(5)            Compare ST(0) with ST(5) and pop  */
					case 0xee:	/* FUCOMP ST(6)            Compare ST(0) with ST(6) and pop  */
					case 0xef:	/* FUCOMP ST(7)            Compare ST(0) with ST(7) and pop  */
						/*
						//*** need implementation
                  				fpuSetPointers(0, 0xDD00 | dest.modrm);
                  				*/
						break;
					default:
						TRACK_INIT_FPU(c->instr, TRACK_FPU_LAST_INSTRUCTION);
						break;
				}
				break;
			case 0xde: /* FPU Group #7 */
				switch(c->instr.fpu.fpu_modrm) { //All FPU ModRM's
					case 0x00:	/* FIADD m16int            Add m16int to ST(0) and s.r.in ST(0) */
						/*
							//source.addr is short*
							i32[0] = readMem(source.addr, SIZE_WORD);
					                  *fp80 = *i16 + fpuPop();
					                  if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
					                     fpuPush(*fp80);
					                  }
					                  fpuSetPointers(source.addr, 0xDE00 | dest.modrm);
						*/
						break;
					case 0x01:	/* FIMUL m16int            Multiply ST(0) by m16int and s.r.in ST(0) */
						/*
							//source.addr is short*
							 i32[0] = readMem(source.addr, SIZE_WORD);
					                  *fp80 = *i16 * fpuPop();
					                  if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
					                     fpuPush(*fp80);
					                  }
					                  fpuSetPointers(source.addr, 0xDE00 | dest.modrm);
						*/
						break;
					case 0x02:	/* FICOM m16int            Compare ST(0) with m16int */
						/*
							//source.addr is short*
							 i32[0] = readMem(source.addr, SIZE_WORD);
					                  fpuCompare(fpuGet(0), *i16);
					                  fpuSetPointers(source.addr, 0xDE00 | dest.modrm);
						*/
						break;
					case 0x03:	/* FICOMP m16int           Compare ST(0) with m16int and pop  */
						/*
							//source.addr is short*
							 i32[0] = readMem(source.addr, SIZE_WORD);
					                  dbl = fpuPop();
					                  if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
					                     fpuCompare(dbl, *i16);
					                  }
					                  fpuSetPointers(source.addr, 0xDE00 | dest.modrm);
						*/
						break;
					case 0x04:	/* FISUB m16int            Sub m16int from ST(0) and s.r.in ST(0) */
						/*
							//source.addr is short*
							i32[0] = readMem(source.addr, SIZE_WORD);
					                  *fp80 = fpuPop() - *i16;
					                  if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
					                     fpuPush(*fp80);
					                  }
					                  fpuSetPointers(source.addr, 0xDE00 | dest.modrm);
						*/
						break;
					case 0x05:	/* FISUBR m16int           Sub ST(0) from m16int and s.r.in ST(0) */
						/*
							//source.addr is short*
 							i32[0] = readMem(source.addr, SIZE_WORD);
					                  *fp80 = *i16 - fpuPop();
					                  if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
					                     fpuPush(*fp80);
					                  }
					                  fpuSetPointers(source.addr, 0xDE00 | dest.modrm);
						*/
						break;
					case 0x06:	/* FIDIV m16int            Divide ST(0) by m64int and s.r.in ST(0) */
						/*
							//source.addr is short*
							i32[0] = readMem(source.addr, SIZE_WORD);
					                  *fp80 = fpuPop() / *i16;
					                  if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
					                     fpuPush(*fp80);
					                  }
					                  fpuSetPointers(source.addr, 0xDE00 | dest.modrm);
						*/
						break;
					case 0x07:	/* FIDIVR m16int           Divide m64int by ST(0) and s.r.in ST(0) */
						/*
							//source.addr is short*
							i32[0] = readMem(source.addr, SIZE_WORD);
				                  *fp80 = *i16 / fpuPop();
				                  if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
				                     fpuPush(*fp80);
				                  }
				                  fpuSetPointers(source.addr, 0xDE00 | dest.modrm);
						*/
						break;
					case 0xc0:	/* FADDP ST(0),ST(0)       Add ST(0) to ST(0), s.r.in ST(0),pop r.stack */
					case 0xc1:	/* FADDP ST(1),ST(0)       Add ST(0) to ST(1), s.r.in ST(1),pop r.stack */
					case 0xc2:	/* FADDP ST(2),ST(0)       Add ST(0) to ST(2), s.r.in ST(2),pop r.stack */
					case 0xc3:	/* FADDP ST(3),ST(0)       Add ST(0) to ST(3), s.r.in ST(3),pop r.stack */
					case 0xc4:	/* FADDP ST(4),ST(0)       Add ST(0) to ST(4), s.r.in ST(4),pop r.stack */
					case 0xc5:	/* FADDP ST(5),ST(0)       Add ST(0) to ST(5), s.r.in ST(5),pop r.stack */
					case 0xc6:	/* FADDP ST(6),ST(0)       Add ST(0) to ST(6), s.r.in ST(6),pop r.stack */
					case 0xc7:	/* FADDP ST(7),ST(0)       Add ST(0) to ST(7), s.r.in ST(7),pop r.stack */
					case 0xc8:	/* FMULP ST(0),ST(0)       Multiply ST(0) by ST(0), s.r.in ST(0) pop  */
					case 0xc9:	/* FMULP ST(1),ST(0)       Multiply ST(1) by ST(0), s.r.in ST(1) pop  */
					case 0xca:	/* FMULP ST(2),ST(0)       Multiply ST(2) by ST(0), s.r.in ST(2) pop  */
					case 0xcb:	/* FMULP ST(3),ST(0)       Multiply ST(3) by ST(0), s.r.in ST(3) pop  */
					case 0xcc:	/* FMULP ST(4),ST(0)       Multiply ST(4) by ST(0), s.r.in ST(4) pop  */
					case 0xcd:	/* FMULP ST(5),ST(0)       Multiply ST(5) by ST(0), s.r.in ST(5) pop  */
					case 0xce:	/* FMULP ST(6),ST(0)       Multiply ST(6) by ST(0), s.r.in ST(6) pop  */
					case 0xcf:	/* FMULP ST(7),ST(0)       Multiply ST(7) by ST(0), s.r.in ST(7) pop  */
					 	/*
					 	int lower = c->instr.fpu.fpu_modrm & 0x0F;
				                *fp80 = fpuGet(lower & 7);
				                if (lower < 8) {          //FADDP  ST(i), ST(0)
				                   *fp80 = *fp80 + fpuGet(0);
				                } else {          //FMULP  ST(i), ST(0)
				                   *fp80 = *fp80 * fpuGet(0);
				                }
				                fpuSet(lower & 7, *fp80);
				                fpuPop();
				                fpuSetPointers(0, 0xDEC0 + lower);
				                */
						break;
					case 0xe0:	/* FSUBRP ST(0),ST(0)      Sub ST(0) from ST(0), s.r. in ST(0) pop  */
					case 0xe1:	/* FSUBRP ST(1),ST(0)      Sub ST(1) from ST(0), s.r. in ST(1) pop ) */
					case 0xe2:	/* FSUBRP ST(2),ST(0)      Sub ST(2) from ST(0), s.r. in ST(2) pop  */
					case 0xe3:	/* FSUBRP ST(3),ST(0)      Sub ST(3) from ST(0), s.r. in ST(3) pop  */
					case 0xe4:	/* FSUBRP ST(4),ST(0)      Sub ST(4) from ST(0), s.r. in ST(4) pop  */
					case 0xe5:	/* FSUBRP ST(5),ST(0)      Sub ST(5) from ST(0), s.r. in ST(5) pop  */
					case 0xe6:	/* FSUBRP ST(6),ST(0)      Sub ST(6) from ST(0), s.r. in ST(6) pop  */
					case 0xe7:	/* FSUBRP ST(7),ST(0)      Sub ST(7) from ST(0), s.r. in ST(7) pop  */
					case 0xe8:	/* FSUBP ST(0),ST(0)       Sub ST(0) from ST(0), s.r.in ST(0) pop */
					case 0xe9:	/* FSUBP ST(1),ST(0)       Sub ST(0) from ST(1), s.r.in ST(1) pop */
					case 0xea:	/* FSUBP ST(2),ST(0)       Sub ST(0) from ST(2), s.r.in ST(2) pop */
					case 0xeb:	/* FSUBP ST(3),ST(0)       Sub ST(0) from ST(3), s.r.in ST(3) pop */
					case 0xec:	/* FSUBP ST(4),ST(0)       Sub ST(0) from ST(4), s.r.in ST(4) pop */
					case 0xed:	/* FSUBP ST(5),ST(0)       Sub ST(0) from ST(5), s.r.in ST(5) pop */
					case 0xee:	/* FSUBP ST(6),ST(0)       Sub ST(0) from ST(6), s.r.in ST(6) pop */
					case 0xef:	/* FSUBP ST(7),ST(0)       Sub ST(0) from ST(7), s.r.in ST(7) pop */
					 	/*
					 	int lower = c->instr.fpu.fpu_modrm & 0x0F;
						*fp80 = fpuGet(lower & 7);
				                if (lower >= 8) {          //FSUBP  ST(i), ST(0)
				                   *fp80 = *fp80 - fpuGet(0);
				                } else {               //FSUBRP  ST(i), ST(0)
				                   *fp80 = fpuGet(0) - *fp80;
				                }
				                fpuSet(lower & 7, *fp80);
				                fpuPop();
				                fpuSetPointers(0, 0xDEE0 + lower);
				                */
						break;
					case 0xd9:	/* FCOMPP                  Compare ST(0) with ST(1), pop pop */
						/*
						dbl = fpuPop();
				                if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
				                	*fp80 = fpuPop();
				                        if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
				                           fpuCompare(dbl, *fp80);
				                        }
				                }
				                fpuSetPointers(0, 0xDED9);
				                */
						break;
					case 0xf0:	/* FDIVRP ST(0),ST(0)      Divide ST(0) by ST(0), s.r.in ST(0) pop  */
					case 0xf1:	/* FDIVRP ST(1),ST(0)      Divide ST(0) by ST(1), s.r.in ST(1) pop  */
					case 0xf2:	/* FDIVRP ST(2),ST(0)      Divide ST(0) by ST(2), s.r.in ST(2) pop  */
					case 0xf3:	/* FDIVRP ST(3),ST(0)      Divide ST(0) by ST(3), s.r.in ST(3) pop  */
					case 0xf4:	/* FDIVRP ST(4),ST(0)      Divide ST(0) by ST(4), s.r.in ST(4) pop  */
					case 0xf5:	/* FDIVRP ST(5),ST(0)      Divide ST(0) by ST(5), s.r.in ST(5) pop  */
					case 0xf6:	/* FDIVRP ST(6),ST(0)      Divide ST(0) by ST(6), s.r.in ST(6) pop  */
					case 0xf7:	/* FDIVRP ST(7),ST(0)      Divide ST(0) by ST(7), s.r.in ST(7) pop  */
					case 0xf8:	/* FDIVP ST(0),ST(0)       Divide ST(0) by ST(0), s.r.in ST(0) pop  */
					case 0xf9:	/* FDIVP ST(1),ST(0)       Divide ST(1) by ST(0), s.r.in ST(1) pop  */
					case 0xfa:	/* FDIVP ST(2),ST(0)       Divide ST(2) by ST(0), s.r.in ST(2) pop  */
					case 0xfb:	/* FDIVP ST(3),ST(0)       Divide ST(3) by ST(0), s.r.in ST(3) pop  */
					case 0xfc:	/* FDIVP ST(4),ST(0)       Divide ST(4) by ST(0), s.r.in ST(4) pop  */
					case 0xfd:	/* FDIVP ST(5),ST(0)       Divide ST(5) by ST(0), s.r.in ST(5) pop  */
					case 0xfe:	/* FDIVP ST(6),ST(0)       Divide ST(6) by ST(0), s.r.in ST(6) pop  */
					case 0xff:	/* FDIVP ST(7),ST(0)       Divide ST(7) by ST(0), s.r.in ST(7) pop  */
				        	/*
				                *fp80 = fpuGet(lower & 7);
				                if (lower >= 8) {          //FDIVP  ST(i), ST(0)
				                   *fp80 = *fp80 / fpuGet(0);
				                }  else {                  //FDIVRP  ST(i), ST(0)
				                   *fp80 = fpuGet(0) / *fp80;
				                }
				                fpuSet(lower & 7, *fp80);
				                fpuPop();
				                fpuSetPointers(0, 0xDEF0 + lower);
				        	*/
				        	break;
					default:
						TRACK_INIT_FPU(c->instr, TRACK_FPU_LAST_INSTRUCTION);
						break;
				}
				break;
			case 0xdf: /* FPU Group #8 */
				switch(c->instr.fpu.fpu_modrm) { //All FPU ModRM's
					case 0x00:	/* FILD m16int             Push m16int  */
						/*
							//source.addr is short*
					                  i32[0] = readMem(source.addr, SIZE_WORD);
					                  fpuPush(*i16);
					                  fpuSetPointers(source.addr, 0xDF00 | dest.modrm);
						*/
						break;
					case 0x01:	/* FISTTP m16int, ST(0)             Store Integer with Truncation and Pop */
						/*
								//source.addr is short*
					                  *i16 = (short)fpuPop();
					                  if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
					                     writeMem(source.addr, i32[0], SIZE_WORD);
					                  }
					                  fpuSetPointers(source.addr, 0xDF00 | dest.modrm);
						*/
						break;
					case 0x02:	/* FIST m16int             Store ST(0) in m16int */
						/*
						 	//source.addr is short*
					                  *i16 = (short)fpuGet(0);
					                  writeMem(source.addr, i32[0], SIZE_WORD);
					                  fpuSetPointers(source.addr, 0xDF00 | dest.modrm);
						*/
						break;
					case 0x03:	/* FISTP m16int            Store ST(0) in m16int and pop  */
						/*
							//source.addr is short*
					                  *i16 = (short)fpuPop();
					                  if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
					                     writeMem(source.addr, i32[0], SIZE_WORD);
					                  }
					                  fpuSetPointers(source.addr, 0xDF00 | dest.modrm);
						*/
						break;
					case 0x04:	/* FBLD m80bcd             Convert m80BCD to real and push  */
						/*
							//source.addr is packed bcd* (10 bytes)
					                  i32[0] = readMem(source.addr, SIZE_DWORD);
					                  i32[1] = readMem(source.addr + 4, SIZE_DWORD);
					                  i32[2] = readMem(source.addr + 8, SIZE_WORD);
						*/
						break;
					case 0x05:	/* FILD m64int             Push m64int */
						/*
							//source.addr is qword*
					                  i32[0] = readMem(source.addr, SIZE_DWORD);
					                  i32[1] = readMem(source.addr + 4, SIZE_DWORD);
					                  fpuPush(*fp80);
					                  fpuSetPointers(source.addr, 0xDF00 | dest.modrm);
						*/
						break;
					case 0x06:	/* FBSTP m80bcd            Store ST(0) in m80bcd and pop ST(0) */
						/*
							//source.addr is packed bcd* (10 bytes)
					                  //*** need implementation
					                  fpuSetPointers(0, 0xDF00 | dest.modrm);
						*/
						break;
					case 0x07:	/* FISTP m64int            Store ST(0) in m64int and pop  */
						/*
							//source.addr is qword*
					                  *i64 = (quad)fpuPop();
					                  if (FPU_MASK_GET(FPU_INVALID) || !FPU_GET(FPU_STACKFAULT)) {
					                     writeMem(source.addr, i32[0], SIZE_DWORD);
					                     writeMem(source.addr + 4, i32[1], SIZE_DWORD);
					                  }
					                  fpuSetPointers(source.addr, 0xDF00 | dest.modrm);
						*/
						break;
					case 0xc0:	/* FFREEP ST(0) Sets tag for ST(0) to empty and pop stack */
					case 0xc1:	/* FFREEP ST(1) Sets tag for ST(0) to empty and pop stack  */
					case 0xc2:	/* FFREEP ST(2) Sets tag for ST(0) to empty and pop stack  */
					case 0xc3:	/* FFREEP ST(3) Sets tag for ST(0) to empty and pop stack  */
					case 0xc4:	/* FFREEP ST(4) Sets tag for ST(0) to empty and pop stack  */
					case 0xc5:	/* FFREEP ST(5) Sets tag for ST(0) to empty and pop stack  */
					case 0xc6:	/* FFREEP ST(6) Sets tag for ST(0) to empty and pop stack  */
					case 0xc7:	/* FFREEP ST(7) Sets tag for ST(0) to empty and pop stack  */
						/*
							//*** need implementation
                     					fpuSetPointers(source.addr, 0xDF00 | dest.modrm);
						*/
						break;
					case 0xe0:	/* FNSTSW AX               Store FPU status word in AX without*/
						/*
							eax = (eax & 0xFFFF0000) | fpu.status;
						*/
						break;
					case 0xe8:	/* FUCOMIP ST(0), ST(0)        Compare ST(0) with ST(0), check ovssf pop */
					case 0xe9:	/* FUCOMIP ST(0), ST(1)        Compare ST(0) with ST(1), check ovssf pop */
					case 0xea:	/* FUCOMIP ST(0), ST(2)        Compare ST(0) with ST(2), check ovssf pop */
					case 0xeb:	/* FUCOMIP ST(0), ST(3)        Compare ST(0) with ST(3), check ovssf pop */
					case 0xec:	/* FUCOMIP ST(0), ST(4)        Compare ST(0) with ST(4), check ovssf pop */
					case 0xed:	/* FUCOMIP ST(0), ST(5)        Compare ST(0) with ST(5), check ovssf pop */
					case 0xee:	/* FUCOMIP ST(0), ST(6)        Compare ST(0) with ST(6), check ovssf pop */
					case 0xef:	/* FUCOMIP ST(0), ST(7)        Compare ST(0) with ST(7), check ovssf pop */
						/*
							//*** need implementation
                     					fpuSetPointers(source.addr, 0xDF00 | dest.modrm);
						*/
						break;
					case 0xf0:	/* FCOMIP ST(0), ST(0)         Compare ST(0) with ST(0), set s.f. ,pop */
					case 0xf1:	/* FCOMIP ST(0), ST(1)         Compare ST(0) with ST(1), set s.f. ,pop */
					case 0xf2:	/* FCOMIP ST(0), ST(2)         Compare ST(0) with ST(2), set s.f. ,pop */
					case 0xf3:	/* FCOMIP ST(0), ST(3)         Compare ST(0) with ST(3), set s.f. ,pop */
					case 0xf4:	/* FCOMIP ST(0), ST(4)         Compare ST(0) with ST(4), set s.f. ,pop */
					case 0xf5:	/* FCOMIP ST(0), ST(5)         Compare ST(0) with ST(5), set s.f. ,pop */
					case 0xf6:	/* FCOMIP ST(0), ST(6)         Compare ST(0) with ST(6), set s.f. ,pop */
					case 0xf7:	/* FCOMIP ST(0), ST(7)         Compare ST(0) with ST(7), set s.f. ,pop */
						/*
							//*** need implementation
                     					fpuSetPointers(source.addr, 0xDF00 | dest.modrm);
						*/
						break;
					default:
						TRACK_INIT_FPU(c->instr, TRACK_FPU_LAST_INSTRUCTION);
						break;
				}
				break;
			default:
				TRACK_INIT_FPU(c->instr, TRACK_FPU_LAST_INSTRUCTION);
				break;
		}
	}


	if (print_instruction)
		debug_instruction(&c->instr);
//	emu_cpu_debug_print(c);

	return ret;
}